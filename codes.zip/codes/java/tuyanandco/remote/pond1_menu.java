package tuyanandco.remote;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;

import java.util.Timer;
import java.util.TimerTask;

public class pond1_menu extends AppCompatActivity {

    UserDB db;
    private String number;
    Button paddle_on, paddle_off, light_off, light_on, feeding_on, feeding_off, supply_on, supply_off, drain_on, drain_off;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pond1);
        initViews();
        db = new UserDB(this);


        paddle_on.setEnabled(false);
        Timer buttonTimer = new Timer();
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        paddle_on.setEnabled(true);
                    }
                });
            }
        }, 3000);

        paddle_off.setEnabled(false);
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        paddle_off.setEnabled(true);
                    }
                });
            }
        }, 3000);

        feeding_on.setEnabled(false);
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        feeding_on.setEnabled(true);
                    }
                });
            }
        }, 3000);

        feeding_off.setEnabled(false);
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        feeding_off.setEnabled(true);
                    }
                });
            }
        }, 3000);

        light_on.setEnabled(false);
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        light_on.setEnabled(true);
                    }
                });
            }
        }, 3000);

        light_off.setEnabled(false);
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        light_off.setEnabled(true);
                    }
                });
            }
        }, 3000);

        supply_on.setEnabled(false);
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        supply_on.setEnabled(true);
                    }
                });
            }
        }, 3000);

        supply_off.setEnabled(false);
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        supply_off.setEnabled(true);
                    }
                });
            }
        }, 3000);

        drain_on.setEnabled(false);
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        drain_on.setEnabled(true);
                    }
                });
            }
        }, 3000);

        drain_off.setEnabled(false);
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        drain_off.setEnabled(true);
                    }
                });
            }
        }, 3000);
    }

    public void paddle_on (View v)
    {
        String msg = "padon";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }

    public void paddle_off (View v)
    {
        String msg = "padoff";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }

    public void feed_on (View v)
    {
        String msg = "feedon";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }

    public void feed_off (View v)
    {
        String msg = "feedoff";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }

    public void light_on (View v)
    {
        String msg = "lighton";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }
    public void light_off (View v)
    {
        String msg = "lightoff";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }
    public void supply_on (View v)
    {
        String msg = "supplyon";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }
    public void supply_off (View v)
    {
        String msg = "supplyoff";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }
    public void drain_on (View v)
    {
        String msg = "drainon";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }
    public void drain_off (View v)
    {
        String msg = "drainoff";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }

    public void back (View v)
    {
        Intent i = new Intent(this, Menu.class);
        startActivity(i);
        finish();
    }

    public void pondTwo2 (View v)
    {
        Intent i = new Intent(this, pond2_menu.class);
        startActivity(i);
        finish();
    }

    public void temp (View v)
    {
        String msg = "tempstatus";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }

    public void water (View v)
    {
        String msg = "waterlevelstatus";
        SmsManager.getDefault().sendTextMessage(number, null, msg, null,null);
    }

    private void initViews ()
    {

        paddle_on = (Button) findViewById(R.id.paddle_on);
        paddle_off = (Button) findViewById(R.id.paddle_off);
        light_on = (Button) findViewById(R.id.light_on);
        light_off = (Button) findViewById(R.id.light_off);
        feeding_off = (Button) findViewById(R.id.feeding_off);
        feeding_on = (Button) findViewById(R.id.feeding_on);
        supply_off = (Button) findViewById(R.id.supply_off);
        supply_on = (Button) findViewById(R.id.supply_on);
        drain_on = (Button) findViewById(R.id.drain_on);
        drain_off = (Button) findViewById(R.id.drain_off);
    }
}
