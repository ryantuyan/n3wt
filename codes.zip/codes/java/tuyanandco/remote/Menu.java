package tuyanandco.remote;

import android.content.Intent;
import android.database.Cursor;
import android.os.Handler;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

import java.util.ArrayList;

public class Menu extends AppCompatActivity{

    EditText sim_et;
    Button editSimNumber;
    UserDB db;
    Cursor cur;
    String simNumber;

    private RelativeLayout settingsLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        db = new UserDB(this);
        settingsLayout = (RelativeLayout) findViewById(R.id.settingsLayout);
        editSimNumber = (Button) findViewById(R.id.editNumberButton);

        String dbsim = db.getSim();
//        sim_et.setText(dbsim);
        editSimNumber.setOnClickListener(simClick);
    }

    private View.OnClickListener simClick = new View.OnClickListener() {
        public void onClick(View v) {
            sim_et = (EditText) findViewById(R.id.simNumEt);
            String simNumber = sim_et.getText().toString().trim();

            if (simNumber != null){
                db.setSimNumber(simNumber);
                Snackbar.make(settingsLayout, "Sim number set!", Snackbar.LENGTH_LONG).show();
            }
            else if (simNumber == null)
            {
                Snackbar.make(settingsLayout, "Input sim number", Snackbar.LENGTH_LONG).show();
            }
//
//            editSimNumber.setEnabled(false);
//
//            new Handler().postDelayed(new Runnable() {
//
//                @Override
//                public void run() {
//                    // This method will be executed once the timer is over
//                    editSimNumber.setEnabled(true);
//                }
//            },5000);// set time delay (1000 = 1 second)
        }
    };

    /*Method to switch to pond one menu*/
    public void pondOne (View v)
    {
        Intent i = new Intent(this, pond1_menu.class);
        startActivity(i);
    }

    /*Method to switch to pond two menu*/
    public void pondTwo (View v)
    {
        Intent i = new Intent(this, pond2_menu.class);
        startActivity(i);
    }


    public void logout (View v)
    {
        Intent i = new Intent (this, LoginActivity.class);
        startActivity(i);
        finish();

    }

    /*method to set sim number on button click*/
    public void setSimNumber()
    {
        String num = sim_et.getText().toString().trim();
        db.setSimNumber(num);
    }
}
